import webview

"""
This example demonstrates how to create a webview window.
"""

if __name__ == '__main__':
    # Create a standard webview window
    webview.create_window("Simple browser", "http://www.flowrl.com")

