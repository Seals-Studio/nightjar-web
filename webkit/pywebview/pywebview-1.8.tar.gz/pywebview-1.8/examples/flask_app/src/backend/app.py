"""
Application stub
"""


def initialize():
    # perform heavy stuff here
    return True


def do_stuff():
    # do whatever you need to do
    response = "This is response from Python backend"
    return response